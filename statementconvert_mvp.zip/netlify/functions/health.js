/**
 * GET /api/health
 * Quick liveness check. Returns 200 if the function runtime is up
 * and the ANTHROPIC_API_KEY env var is set.
 */
exports.handler = async function () {
  const hasKey = !!process.env.ANTHROPIC_API_KEY;
  return {
    statusCode: hasKey ? 200 : 503,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      ok: hasKey,
      service: 'StatementConvert',
      version: '1.0.0-mvp',
      api_key_configured: hasKey,
      ts: new Date().toISOString(),
    }),
  };
};
