/**
 * StatementConvert — /api/track
 * Lightweight analytics endpoint.
 * Receives fire-and-forget events from the frontend via navigator.sendBeacon.
 *
 * MVP approach: logs to Netlify function logs (visible in Netlify dashboard).
 * Later: swap the console.log for Plausible, PostHog, or any analytics SDK.
 *
 * Events tracked:
 *   page_view, cta_click, demo_started, demo_completed,
 *   file_selected, conversion_started, conversion_success, conversion_error,
 *   export_clicked, pricing_viewed, checkout_started, payment_success
 */

exports.handler = async function (event) {
  // Only POST (sendBeacon sends POST)
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: '' };
  }

  let payload;
  try {
    payload = JSON.parse(event.body || '{}');
  } catch {
    return { statusCode: 400, body: '' };
  }

  const { event: evtName, props = {}, url, ts } = payload;

  // Sanitise — drop anything that looks like PII
  const safeProps = {};
  const ALLOWED_KEYS = [
    'lang', 'ext', 'size_kb', 'tx_count', 'format',
    'code', 'is_demo', 'destination', 'plan', 'price_id',
  ];
  for (const k of ALLOWED_KEYS) {
    if (props[k] !== undefined) safeProps[k] = props[k];
  }

  // Structured log — shows up in Netlify Functions log stream
  console.log(JSON.stringify({
    t: 'track',
    evt: evtName || 'unknown',
    props: safeProps,
    url: url || '/',
    client_ts: ts || null,
    server_ts: Date.now(),
  }));

  // sendBeacon expects a 2xx — return 204 No Content
  return { statusCode: 204, body: '' };
};
