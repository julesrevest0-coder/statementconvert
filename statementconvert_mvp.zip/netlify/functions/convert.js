/**
 * StatementConvert — /api/convert
 * MVP backend: receives a bank statement file (base64),
 * calls Claude API to extract structured transactions,
 * returns JSON.
 *
 * Supports: PDF, CSV, Excel (as text), JPG, PNG
 * Max payload: ~8MB base64 (~6MB raw file)
 */

const MAX_BYTES = 8 * 1024 * 1024; // 8MB body limit

const ALLOWED_MIME = [
  'application/pdf',
  'text/csv',
  'text/plain',
  'application/vnd.ms-excel',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  'image/jpeg',
  'image/png',
  'image/webp',
];

const SYSTEM_PROMPT = `You are a bank statement parser. Your only job is to extract transactions from the document provided and return them as structured JSON.

Rules:
- Extract ALL transactions visible in the document.
- Return ONLY valid JSON, nothing else — no markdown, no explanation, no code fences.
- If the document is not a bank statement or you cannot extract transactions, return: {"error":"not_a_statement"}
- If the document is unreadable or corrupted, return: {"error":"unreadable"}
- Dates: use ISO format YYYY-MM-DD when possible, otherwise keep the original format exactly as printed.
- Amounts: positive numbers for credits/income, negative numbers for debits/expenses. Numbers only, no currency symbols.
- Balance: running balance after each transaction, if available. null if not present.
- Category: best-guess category from this list: Income, Groceries, Transport, Housing, Utilities, Subscriptions, Health, Dining, Shopping, Travel, Entertainment, Transfer, Fees, Other.
- Description: clean the raw description, remove excess codes/spaces, keep it readable.

Return format (JSON only, no wrapper):
{
  "currency": "EUR",
  "account_name": "...",
  "statement_period": "...",
  "transactions": [
    {
      "date": "2024-03-01",
      "description": "Netflix",
      "amount": -15.99,
      "balance": 4284.01,
      "category": "Subscriptions",
      "raw": "NETFLIX.COM 123456"
    }
  ]
}`;

exports.handler = async function (event, context) {
  // CORS headers — allow the Netlify domain and localhost for dev
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Content-Type': 'application/json',
  };

  // Handle preflight
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 204, headers, body: '' };
  }

  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers, body: JSON.stringify({ error: 'method_not_allowed' }) };
  }

  // Check API key is configured
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    console.error('[convert] ANTHROPIC_API_KEY not set');
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: 'server_misconfigured', message: 'API key not configured.' }),
    };
  }

  // Parse body
  let body;
  try {
    body = JSON.parse(event.body);
  } catch {
    return { statusCode: 400, headers, body: JSON.stringify({ error: 'invalid_json' }) };
  }

  const { file, mimeType, filename } = body;

  // Validate inputs
  if (!file || !mimeType) {
    return {
      statusCode: 400,
      headers,
      body: JSON.stringify({ error: 'missing_fields', message: 'file and mimeType are required.' }),
    };
  }

  if (!ALLOWED_MIME.includes(mimeType)) {
    return {
      statusCode: 415,
      headers,
      body: JSON.stringify({
        error: 'unsupported_format',
        message: `Format not supported: ${mimeType}. Supported: PDF, CSV, Excel, JPG, PNG.`,
      }),
    };
  }

  // Check size
  const byteLength = Buffer.byteLength(file, 'base64');
  if (byteLength > MAX_BYTES) {
    return {
      statusCode: 413,
      headers,
      body: JSON.stringify({
        error: 'file_too_large',
        message: 'File exceeds 8MB limit. Try a smaller file or split it.',
      }),
    };
  }

  // Build the Claude API message
  // For text-based formats (CSV, Excel as text), send as text content
  // For PDF and images, send as base64 media
  let userContent;
  const isTextFormat = mimeType === 'text/csv' || mimeType === 'text/plain';

  if (isTextFormat) {
    // Decode base64 to text and send as plain text
    const text = Buffer.from(file, 'base64').toString('utf-8');
    userContent = [
      {
        type: 'text',
        text: `Extract all transactions from this bank statement file (${filename || 'file'}):\n\n${text}`,
      },
    ];
  } else if (mimeType === 'application/pdf') {
    userContent = [
      {
        type: 'document',
        source: { type: 'base64', media_type: 'application/pdf', data: file },
      },
      {
        type: 'text',
        text: `Extract all transactions from this bank statement PDF (${filename || 'document'}).`,
      },
    ];
  } else {
    // Image formats
    userContent = [
      {
        type: 'image',
        source: { type: 'base64', media_type: mimeType, data: file },
      },
      {
        type: 'text',
        text: `Extract all transactions from this bank statement image (${filename || 'image'}).`,
      },
    ];
  }

  // Call Claude API
  let claudeResponse;
  try {
    const apiResponse = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
        'anthropic-beta': 'pdfs-2024-09-25', // Enable PDF support
      },
      body: JSON.stringify({
        model: 'claude-opus-4-5',
        max_tokens: 8000,
        system: SYSTEM_PROMPT,
        messages: [{ role: 'user', content: userContent }],
      }),
    });

    if (!apiResponse.ok) {
      const errText = await apiResponse.text();
      console.error('[convert] Claude API error:', apiResponse.status, errText);

      if (apiResponse.status === 429) {
        return {
          statusCode: 429,
          headers,
          body: JSON.stringify({
            error: 'rate_limited',
            message: 'Too many requests. Please wait a moment and try again.',
          }),
        };
      }
      throw new Error(`Claude API ${apiResponse.status}`);
    }

    claudeResponse = await apiResponse.json();
  } catch (err) {
    console.error('[convert] Fetch error:', err);
    return {
      statusCode: 502,
      headers,
      body: JSON.stringify({
        error: 'extraction_failed',
        message: 'Could not reach the extraction service. Please try again.',
      }),
    };
  }

  // Parse Claude's response
  const rawText = claudeResponse.content
    ?.filter((b) => b.type === 'text')
    .map((b) => b.text)
    .join('');

  if (!rawText) {
    return {
      statusCode: 502,
      headers,
      body: JSON.stringify({ error: 'empty_response', message: 'Extraction returned no data.' }),
    };
  }

  // Strip any accidental markdown fences
  const cleaned = rawText.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/i, '').trim();

  let parsed;
  try {
    parsed = JSON.parse(cleaned);
  } catch {
    console.error('[convert] JSON parse failed. Raw:', rawText.slice(0, 300));
    return {
      statusCode: 422,
      headers,
      body: JSON.stringify({
        error: 'parse_failed',
        message: 'Could not parse the extracted data. Please try a different file.',
      }),
    };
  }

  // Surface extraction errors
  if (parsed.error) {
    const messages = {
      not_a_statement: 'This file does not appear to be a bank statement.',
      unreadable: 'The file is unreadable or corrupted. Try exporting it again from your bank.',
    };
    return {
      statusCode: 422,
      headers,
      body: JSON.stringify({
        error: parsed.error,
        message: messages[parsed.error] || 'Could not extract transactions from this file.',
      }),
    };
  }

  // Validate we got transactions
  if (!Array.isArray(parsed.transactions) || parsed.transactions.length === 0) {
    return {
      statusCode: 422,
      headers,
      body: JSON.stringify({
        error: 'no_transactions',
        message: 'No transactions found in this file. Is it a bank statement?',
      }),
    };
  }

  // Success — return structured data
  console.log(`[convert] OK — ${parsed.transactions.length} transactions extracted from ${filename || 'file'}`);

  return {
    statusCode: 200,
    headers,
    body: JSON.stringify({
      ok: true,
      currency: parsed.currency || 'EUR',
      account_name: parsed.account_name || null,
      statement_period: parsed.statement_period || null,
      transaction_count: parsed.transactions.length,
      transactions: parsed.transactions,
    }),
  };
};
