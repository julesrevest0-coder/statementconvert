# StatementConvert — MVP Deployment Guide

## Structure

```
/
├── index.html                  → Landing page + upload page (single-file SPA)
├── netlify.toml                → Build config, redirects, security headers
├── package.json                → Node environment signal for Netlify
├── netlify/functions/
│   ├── convert.js              → [N1] PDF/CSV/image → transactions (Claude API)
│   ├── health.js               → [N1] GET /api/health — liveness check
│   └── track.js                → [N1] POST /api/track — event logging
```

---

## Deploy to Netlify (< 5 minutes)

### 1. Push to GitHub

```bash
git init
git add .
git commit -m "StatementConvert MVP"
git remote add origin https://github.com/YOUR_USER/statementconvert.git
git push -u origin main
```

### 2. Connect to Netlify

1. Go to [netlify.com](https://netlify.com) → **Add new site** → **Import from Git**
2. Select your repo
3. Build settings are auto-detected from `netlify.toml`:
   - **Publish directory:** `.`
   - **Functions directory:** `netlify/functions`
4. Click **Deploy site**

### 3. Set environment variables (required)

In Netlify dashboard → **Site settings** → **Environment variables**:

| Variable | Value | Required |
|----------|-------|----------|
| `ANTHROPIC_API_KEY` | `sk-ant-...` | ✅ Yes |

Get your key at [console.anthropic.com](https://console.anthropic.com)

> **Note:** The free tier of the Anthropic API covers early testing.
> Claude claude-opus-4-5 is used for best extraction accuracy.
> Cost per conversion: ~$0.005–$0.02 depending on PDF size.

### 4. Verify deployment

Visit `https://YOUR-SITE.netlify.app/api/health` — you should see:
```json
{ "ok": true, "api_key_configured": true }
```

If `api_key_configured` is `false`, the env var is not set.

### 5. Stripe (for paid plans)

The Stripe public key is already in `index.html`.
To activate paid plans, replace `price_STARTER` and `price_PRO` with real Stripe Price IDs:

1. Create products in [Stripe Dashboard](https://dashboard.stripe.com/products)
2. Copy the Price IDs (format: `price_1ABC...`)
3. In `index.html`, find `stripeCheckout` and replace the placeholder price IDs
4. Add your Stripe webhook secret as env var `STRIPE_WEBHOOK_SECRET` (optional for MVP)

---

## Local development

```bash
npm install -g netlify-cli
netlify dev
```

This runs the site + functions locally at `http://localhost:8888`.
You need `ANTHROPIC_API_KEY` in a `.env` file at the root:

```
ANTHROPIC_API_KEY=sk-ant-...
```

---

## Tracking

Events are logged to **Netlify Function logs** (visible in dashboard → Functions → convert/track).

Events tracked:
- `page_view` — every page load
- `cta_click` — hero CTA clicked
- `file_selected` — file chosen (ext, size_kb)
- `conversion_started` — convert button clicked
- `conversion_success` — extraction succeeded (tx_count)
- `conversion_error` — extraction failed (error code)
- `export_clicked` — download button clicked (format, tx_count)
- `pricing_viewed` — pricing section scrolled to
- `checkout_started` — Stripe checkout initiated
- `payment_success` — returned from Stripe with ?payment=success
- `demo_started` / `demo_completed` — landing demo interaction

To add a real analytics provider later (Plausible, PostHog):
1. Add the SDK to `index.html`
2. Update the `track()` function in the JS to call the SDK alongside `sendBeacon`

---

## Cost estimate (MVP phase)

| Usage | Anthropic API cost |
|-------|-------------------|
| 100 conversions/month | ~$1–5 |
| 1,000 conversions/month | ~$10–50 |

Netlify free tier: 125k function invocations/month — well above MVP needs.

---

## What's NOT built yet (intentionally deferred)

- [ ] User accounts / authentication
- [ ] Conversion history storage
- [ ] Email notifications
- [ ] Admin dashboard
- [ ] Webhook to accounting software
- [ ] Multi-language UI beyond EN/FR
- [ ] SSO / enterprise features
- [ ] SLA monitoring

These are all **Niveau 3** — build only when the market validates the core.

---

## Support

For questions or issues: hello@statementconvert.app
